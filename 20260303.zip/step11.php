<?php
ob_end_clean();
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('display_errors',true);
//date_default_timezone_set('Europe/London');
include 'connection.php';

$sql = "DELETE FROM `racebets_todo` WHERE 1";
mysqli_query($con,$sql) or die($sql);

$date = $_GET['date'];
$dayname = str_replace('-', '', $date);
//for($i=0;$i>=0;$i--)
//{
    //$date = date('Y-m-d',time()-1*24*60*60);
    //$date = '2023-10-06';
    //echo $date."<br>";
    //exit();
    //$dayname = date('Ym',time()-1*24*60*60);
    
    $folderPath = "$dayname";
    if (!is_dir($folderPath)) {
        mkdir($folderPath, 0777, true);
    }
    
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, 'https://www.racebets.com/ajax/events/calendar/date/'.$date.'?_=1696587409831');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
    
    $headers = array();
    $headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
    $headers[] = 'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,ms;q=0.7,zh-TW;q=0.6,fr;q=0.5,ja;q=0.4,da;q=0.3';
    $headers[] = 'Cookie:rbsid=4f58m4i09natd0c9ff8oa5gd41; Acquisition_Status_Current=Prospect; Start_Acquisition=Prospect; Client_Status_Current=Prospect; Start_Client_Status=Prospect; Customer_Level=PC; Orientation=0; _ga=GA1.1.1000821974.1764997507; Initdone=1; XSRF-TOKEN=f4d5e%3B1772611734%3B18d4968c1f03a9720eaaf23cfcbd0a0b; _ga_2KRPX28VR1=GS2.1.s1772611364$o35$g1$t1772611738$j60$l0$h0; AWSALBTG=bThzIIJOrNiKHPLl/2cr7eBnR2EUwgUl7s+4gUMs3WuJe+Kd7qm8dkO087hFFS8hfaOoYKgk0fcSQrnT30uHRxHuXKFfgaZDYVbgyIgIHJRqgnIkoLW5H4fETxMGrR0oUhomcFml/FkAguaOQK87msf2ygIfvT4EvfP/7pjG/uygXz7Dy0E=; AWSALB=r0nNwdgynSz8LIzTCrPl1re9K7mNEv7gYXHhDQ49Ud3m/nUOtDMuYGa/gO70HCgMbOl9qPXr3EbP2l3bIB3CWDWJcqfQ54oPwxg9Mb+r0FccQ7NPaI2OxFuY1GPZ';
    $headers[] = 'Priority: u=1, i';
    $headers[] = 'Referer: https://m.racebets.com/race/details/id/6349601';
    $headers[] = 'Sec-Ch-Ua: ';
    $headers[] = 'Sec-Ch-Ua-Mobile: ?0';
    $headers[] = 'Sec-Ch-Ua-Platform: ';
    $headers[] = 'Sec-Fetch-Dest: empty';
    $headers[] = 'Sec-Fetch-Mode: cors';
    $headers[] = 'Sec-Fetch-Site: same-origin';
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36';
    $headers[] = 'X-Requested-With: XMLHttpRequest';
    $headers[] = 'X-Xsrf-Token: f4d5e;1772611734;18d4968c1f03a9720eaaf23cfcbd0a0b';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    //echo $result;
    //exit();
    $has = false;
    //echo "<table border='1'><tr><td>country</td><td>raceType</td><td>title</td><td>date</td><td>Day</td><td>raceNumber</td><td>RaceTime</td><td>idRace</td></tr>";
    $json = json_decode($result);
    foreach ($json as $e)
    {
        $country = $e->country;
        $raceType = $e->raceType;
        if($country != "")
        {
            if($raceType == "J" || $raceType == "G")
            {
                if($raceType == "J") $raceType = "Jump Racing";
                if($raceType == "G") $raceType = "Gallop";
                $title = $e->title;
                $Day = date('l',strtotime($date));
                
                foreach ($e->relatedRaces as $d)
                {
                    $idRace= $d->idRace;
                    $postTime= $d->postTime;
                    $raceNumber= $d->raceNumber;
                    $RaceTime = date('H:i',$postTime);
                    
                    $sql = "select * from `racebets_todo` where idRace = '$idRace' limit 1";
                    $rsts = mysqli_query($con,$sql) or die($sql);
                    $detail = mysqli_fetch_array($rsts);
                    $count = mysqli_num_rows($rsts);
                    if($count == 0)
                    {
                        //secho "<tr><td>$country</td><td>$raceType</td><td>$title</td><td>$date</td><td>$Day</td><td>$raceNumber</td><td>$RaceTime</td><td>$idRace</td></tr>";
                        $sql = "INSERT INTO `racebets_todo`(`country`, `raceType`, `title`, `date`, `Day`, `raceNumber`, `RaceTime`, `idRace`) VALUES (
                        '$country','$raceType','".mysqli_real_escape_string($con,$title)."','$date','$Day','$raceNumber','$RaceTime','$idRace')";
                        mysqli_query($con,$sql) or die($sql);
                        echo "new<br>";
                        
                        $has = true;
                    }
                }
            }
        }
    }
    //echo $result;
    
    if($has == true)
    {
        echo '<script language="javascript" type="text/javascript">
window.location.href = "step_2015.php";
</script>';
    }
//}
?>